# Backend-Python
Advanced Python for Backend Specializarion
#
![](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGhadhxEM7auJ-XfAB-grlW0tyWsvqEM9xqN5ereP8r4MTOuJjhsT5Bx2-8KX2BBXcqR0&usqp=CAU)
#
![](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQsNqSmo4X5n3b06rEwNg6TR-lqV82wAckZHURlAd0_2ubt51XESLfzr7q2t7NnY8byOyQ&usqp=CAU)
