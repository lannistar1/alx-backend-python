#!/usr/bin/env python3
"""add basic anotations"""


def add(a: float, b: float) -> float:
    """ take two arguments and return the sum """
    return a + b
